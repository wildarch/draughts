package nl.tue.s2id90.group19;

/**
 *
 * @author huub
 */
public class AIStoppedException extends Exception { }
